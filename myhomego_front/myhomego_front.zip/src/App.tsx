import React from 'react';
import Layout from './components/Layout';
import AnnouncementList from './pages/AnnouncementList';

function App() {
  return (
    <Layout>
      <AnnouncementList />
    </Layout>
  );
}

export default App;
