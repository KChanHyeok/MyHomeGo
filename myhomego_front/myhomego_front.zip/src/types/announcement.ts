export interface Announcement {
  PAN_NM: string;          // 공고명
  PAN_NT_ST_DT: string;   // 공고시작일
  CLSG_DT: string;        // 접수마감일
  CNP_CD_NM: string;      // 지역명
  AIS_TP_CD_NM: string;   // 유형명
  DTL_URL: string;        // 상세링크
  PAN_SS: string;         // 상태
}

export interface LHResponse {
  dsList: Array<{
    PAN_NM: string;          // 공고명
    PAN_NT_ST_DT: string;   // 공고시작일
    CLSG_DT: string;        // 접수마감일
    CNP_CD_NM: string;      // 지역명
    AIS_TP_CD_NM: string;   // 유형명
    DTL_URL: string;        // 상세링크
    PAN_SS: string;         // 상태
  }>;
}
